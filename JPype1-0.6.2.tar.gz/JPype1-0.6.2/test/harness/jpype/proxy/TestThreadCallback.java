package jpype.proxy;

public interface TestThreadCallback {

    public void notifyValue(String step);
    
}
