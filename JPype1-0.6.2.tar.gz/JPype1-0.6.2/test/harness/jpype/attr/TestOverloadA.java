package jpype.attr;

public class TestOverloadA {
    public String foo() {
        return "foo() in A";
    }
}
