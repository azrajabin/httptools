package jpype.exc;

public class ChildTestException extends ParentTestException {
  }