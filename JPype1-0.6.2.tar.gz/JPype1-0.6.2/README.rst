JPype
=====

.. image:: https://travis-ci.org/originell/jpype.png?branch=master
   :target: https://travis-ci.org/originell/jpype

.. image:: https://ci.appveyor.com/api/projects/status/7x9aqpsbcdnl96wt/branch/master
   :target: https://ci.appveyor.com/project/marscher/jpype-555


JPype is an effort to allow python programs full access to java class
libraries. 

Find the `documentation at Read the Docs
<http://jpype.readthedocs.org>`__.  Current development is done in
`the github project <https://github.com/originell/jpype>`__. The work
on this project began on `Sourceforge
<http://sourceforge.net/projects/jpype/>`__.
